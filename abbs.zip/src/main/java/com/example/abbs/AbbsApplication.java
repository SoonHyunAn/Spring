package com.example.abbs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AbbsApplication {

	public static void main(String[] args) {
		SpringApplication.run(AbbsApplication.class, args);
	}

}
